## FontBakery report

fontbakery version: 0.13.2







## Check results



<details><summary>[7] GoogleSansCode[wght].ttf</summary>
<div>
<details>
    <summary>🔥 <b>FAIL</b> Shapes languages in all GF glyphsets. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/googlefonts.html#googlefonts-glyphsets-shape-languages">googlefonts/glyphsets/shape_languages</a></summary>
    <div>







* 🔥 **FAIL** <p>GF_Phonetics_SinoExt glyphset:</p>
<table>
<thead>
<tr>
<th align="left">FAIL messages</th>
<th align="left">Languages</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">Mandatory orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following base characters are missing from the font: GĦ, għ, Ħ, ħ</td>
<td align="left">mt_Latn (Maltese)</td>
</tr>
</tbody>
</table>
 [code: failed-language-shaping]



* ⚠️ **WARN** <p>GF_Phonetics_SinoExt glyphset:</p>
<table>
<thead>
<tr>
<th align="left">WARN messages</th>
<th align="left">Languages</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: º</td>
<td align="left">ca_Latn (Catalan)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ª</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: º</td>
<td align="left">es_Latn (Spanish), it_Latn (Italian) and pt_Latn (Portuguese)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ǥ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ħ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŧ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ʒ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ǯ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ǥ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ħ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŧ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ʒ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ǯ</td>
<td align="left">fi_Latn (Finnish)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to M when shaping the text 'M̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach acutecomb to Uogonek when shaping the text 'Ų́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to Uogonek when shaping the text 'Ų̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach acutecomb to eogonek when shaping the text 'ę́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to eogonek when shaping the text 'ę̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach acutecomb to iogonek when shaping the text 'į́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach uni0307 to iogonek when shaping the text 'į̇́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach acutecomb to uni0307 when shaping the text 'į̇́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to iogonek when shaping the text 'į̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach uni0307 to iogonek when shaping the text 'į̇̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to uni0307 when shaping the text 'į̇̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to m when shaping the text 'm̃'</td>
<td align="left">lt_Latn (Lithuanian)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŧ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŧ</td>
<td align="left">nb_Latn (Norwegian Bokmål)</td>
</tr>
</tbody>
</table>
 [code: warning-language-shaping]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Checking correctness of monospaced metadata. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/opentype.html#opentype-monospace">opentype/monospace</a></summary>
    <div>







* ⚠️ **WARN** <p>The OpenType spec recommends at <a href="https://learn.microsoft.com/en-us/typography/opentype/spec/recom#hhea-table">https://learn.microsoft.com/en-us/typography/opentype/spec/recom#hhea-table</a> that hhea.numberOfHMetrics be set to 3 but this font has 579 instead.
Please read <a href="https://github.com/fonttools/fonttools/issues/3014">https://github.com/fonttools/fonttools/issues/3014</a> to decide whether this makes sense for your font.</p>
 [code: bad-numberOfHMetrics]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Check accent of Lcaron, dcaron, lcaron, tcaron <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#alt-caron">alt_caron</a></summary>
    <div>









* ⚠️ **WARN** <p>Lcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



* ⚠️ **WARN** <p>dcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



* ⚠️ **WARN** <p>lcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



* ⚠️ **WARN** <p>tcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Ensure variable fonts include an avar table. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#mandatory-avar-table">mandatory_avar_table</a></summary>
    <div>







* ⚠️ **WARN** <p>This variable font does not have an avar table. Most variable fonts should include an avar table to correctly define axes progression rates.</p>
 [code: missing-avar]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Name table strings must not contain the string 'Reserved Font Name'. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/googlefonts.html#googlefonts-name-rfn">googlefonts/name/rfn</a></summary>
    <div>







* ⚠️ **WARN** <p>Name table entry contains &quot;Reserved Font Name&quot; for a family name (“Google”) that differs from the currently used family name (GoogleSansCode), which is fine.</p>
 [code: legacy-familyname]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Ensure soft_dotted characters lose their dot when combined with marks that replace the dot. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#soft-dotted">soft_dotted</a></summary>
    <div>







* ⚠️ **WARN** <p>The dot of soft dotted characters used in orthographies <em>must</em> disappear in the following strings: į̀ į́ į̂ į̃ į̄ į̌ ị̀ ị́ ị̂ ị̃ ị̄</p>
<p>The dot of soft dotted characters <em>should</em> disappear in other cases, for example: i̒ ĭ̛ i̛̇ i̛̊ i̛̋ ǐ̛ i̛̒ ĭ̦ i̦̇ i̦̊ i̦̋ ǐ̦ i̦̒ ĭ̧ i̧̇ i̧̊ i̧̋ ǐ̧ i̧̒ j̒</p>
 [code: soft-dotted]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Are there any misaligned on-curve points? <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#outline-alignment-miss">outline_alignment_miss</a></summary>
    <div>







* ⚠️ **WARN** <p>The following glyphs have on-curve points which have potentially incorrect y coordinates:</p>
<pre><code>* at (U+0040): X=225.0,Y=0.5 (should be at baseline 0?)

* bracketleft (U+005B): X=1022.0,Y=1431.0 (should be at cap-height 1432?)

* bracketleft (U+005B): X=536.0,Y=1431.0 (should be at cap-height 1432?)

* bracketright (U+005D): X=664.0,Y=1431.0 (should be at cap-height 1432?)

* bracketright (U+005D): X=178.0,Y=1431.0 (should be at cap-height 1432?)

* i (U+0069): X=468.0,Y=1431.0 (should be at cap-height 1432?)

* i (U+0069): X=772.0,Y=1430.0 (should be at cap-height 1432?)

* j (U+006A): X=557.0,Y=1431.0 (should be at cap-height 1432?)

* j (U+006A): X=861.0,Y=1430.0 (should be at cap-height 1432?)

* l (U+006C): X=950.5,Y=-2.0 (should be at baseline 0?)

* r (U+0072): X=1017.5,Y=1047.5 (should be at x-height 1047?)

* Atilde (U+00C3): X=294.0,Y=1933.0 (should be at ascender 1932?)

* uni1EBC (U+1EBC): X=281.0,Y=1933.0 (should be at ascender 1932?)

* Itilde (U+0128): X=292.0,Y=1933.0 (should be at ascender 1932?)

* Ntilde (U+00D1): X=293.0,Y=1933.0 (should be at ascender 1932?)

* Otilde (U+00D5): X=292.0,Y=1933.0 (should be at ascender 1932?)

* uni1EE0 (U+1EE0): X=952.0,Y=1934.0 (should be at ascender 1932?)

* Utilde (U+0168): X=292.0,Y=1933.0 (should be at ascender 1932?)

* uni1EF8 (U+1EF8): X=295.0,Y=1933.0 (should be at ascender 1932?)

* atilde (U+00E3): X=696.5,Y=1431.0 (should be at cap-height 1432?)

* edotaccent (U+0117): X=468.0,Y=1433.0 (should be at cap-height 1432?)

* edotaccent (U+0117): X=778.0,Y=1433.0 (should be at cap-height 1432?)

* uni1EBD (U+1EBD): X=718.5,Y=1431.0 (should be at cap-height 1432?)

* iogonek (U+012F): X=468.0,Y=1431.0 (should be at cap-height 1432?)

* iogonek (U+012F): X=772.0,Y=1430.0 (should be at cap-height 1432?)

* ij (U+0133): X=215.0,Y=1431.0 (should be at cap-height 1432?)

* ij (U+0133): X=519.0,Y=1430.0 (should be at cap-height 1432?)

* ij (U+0133): X=836.0,Y=1431.0 (should be at cap-height 1432?)

* ij (U+0133): X=1140.0,Y=1430.0 (should be at cap-height 1432?)

* itilde (U+0129): X=743.5,Y=1431.0 (should be at cap-height 1432?)

* uni1ECB (U+1ECB): X=468.0,Y=1431.0 (should be at cap-height 1432?)

* uni1ECB (U+1ECB): X=772.0,Y=1430.0 (should be at cap-height 1432?)

* lacute (U+013A): X=950.5,Y=-2.0 (should be at baseline 0?)

* lcaron (U+013E): X=946.5,Y=-2.0 (should be at baseline 0?)

* uni013C (U+013C): X=950.5,Y=-2.0 (should be at baseline 0?)

* lslash (U+0142): X=950.5,Y=-2.0 (should be at baseline 0?)

* ldot (U+0140): X=950.5,Y=-2.0 (should be at baseline 0?)

* ntilde (U+00F1): X=713.5,Y=1431.0 (should be at cap-height 1432?)

* otilde (U+00F5): X=696.5,Y=1431.0 (should be at cap-height 1432?)

* utilde (U+0169): X=688.5,Y=1431.0 (should be at cap-height 1432?)

* uni1EF9 (U+1EF9): X=711.5,Y=1431.0 (should be at cap-height 1432?)

* zdotaccent (U+017C): X=452.0,Y=1433.0 (should be at cap-height 1432?)

* zdotaccent (U+017C): X=762.0,Y=1433.0 (should be at cap-height 1432?)

* tildecomb (U+0303): X=96.5,Y=1431.0 (should be at cap-height 1432?)

* uni0307 (U+0307): X=-154.0,Y=1433.0 (should be at cap-height 1432?)

* uni0307 (U+0307): X=156.0,Y=1433.0 (should be at cap-height 1432?)
</code></pre>
 [code: found-misalignments]



</div>
</details>
</div>
</details>

<details><summary>[7] GoogleSansCode-Italic[wght].ttf</summary>
<div>
<details>
    <summary>🔥 <b>FAIL</b> Shapes languages in all GF glyphsets. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/googlefonts.html#googlefonts-glyphsets-shape-languages">googlefonts/glyphsets/shape_languages</a></summary>
    <div>







* 🔥 **FAIL** <p>GF_Phonetics_SinoExt glyphset:</p>
<table>
<thead>
<tr>
<th align="left">FAIL messages</th>
<th align="left">Languages</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">Mandatory orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following base characters are missing from the font: għ, GĦ, ħ, Ħ</td>
<td align="left">mt_Latn (Maltese)</td>
</tr>
</tbody>
</table>
 [code: failed-language-shaping]



* ⚠️ **WARN** <p>GF_Phonetics_SinoExt glyphset:</p>
<table>
<thead>
<tr>
<th align="left">WARN messages</th>
<th align="left">Languages</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: º</td>
<td align="left">ca_Latn (Catalan)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ª</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: º</td>
<td align="left">es_Latn (Spanish), it_Latn (Italian) and pt_Latn (Portuguese)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ǥ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ħ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŧ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ʒ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ǯ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ǥ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ħ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŧ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ʒ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ǯ</td>
<td align="left">fi_Latn (Finnish)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to M when shaping the text 'M̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach acutecomb to iogonek when shaping the text 'į́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach uni0307 to iogonek when shaping the text 'į̇́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach acutecomb to uni0307 when shaping the text 'į̇́'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to iogonek when shaping the text 'į̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach uni0307 to iogonek when shaping the text 'į̇̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to uni0307 when shaping the text 'į̇̃'</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">Shaper didn't attach tildecomb to m when shaping the text 'm̃'</td>
<td align="left">lt_Latn (Lithuanian)</td>
</tr>
<tr>
<td align="left">Auxiliary orthography codepoints:</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: Ŧ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŋ</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">The following auxiliary characters are missing from the font: ŧ</td>
<td align="left">nb_Latn (Norwegian Bokmål)</td>
</tr>
</tbody>
</table>
 [code: warning-language-shaping]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Checking correctness of monospaced metadata. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/opentype.html#opentype-monospace">opentype/monospace</a></summary>
    <div>







* ⚠️ **WARN** <p>The OpenType spec recommends at <a href="https://learn.microsoft.com/en-us/typography/opentype/spec/recom#hhea-table">https://learn.microsoft.com/en-us/typography/opentype/spec/recom#hhea-table</a> that hhea.numberOfHMetrics be set to 3 but this font has 579 instead.
Please read <a href="https://github.com/fonttools/fonttools/issues/3014">https://github.com/fonttools/fonttools/issues/3014</a> to decide whether this makes sense for your font.</p>
 [code: bad-numberOfHMetrics]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Check accent of Lcaron, dcaron, lcaron, tcaron <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#alt-caron">alt_caron</a></summary>
    <div>









* ⚠️ **WARN** <p>Lcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



* ⚠️ **WARN** <p>dcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



* ⚠️ **WARN** <p>lcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



* ⚠️ **WARN** <p>tcaron is decomposed and therefore could not be checked. Please check manually.</p>
 [code: decomposed-outline]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Ensure variable fonts include an avar table. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#mandatory-avar-table">mandatory_avar_table</a></summary>
    <div>







* ⚠️ **WARN** <p>This variable font does not have an avar table. Most variable fonts should include an avar table to correctly define axes progression rates.</p>
 [code: missing-avar]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Name table strings must not contain the string 'Reserved Font Name'. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/googlefonts.html#googlefonts-name-rfn">googlefonts/name/rfn</a></summary>
    <div>







* ⚠️ **WARN** <p>Name table entry contains &quot;Reserved Font Name&quot; for a family name (“Google”) that differs from the currently used family name (GoogleSansCode), which is fine.</p>
 [code: legacy-familyname]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Ensure soft_dotted characters lose their dot when combined with marks that replace the dot. <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#soft-dotted">soft_dotted</a></summary>
    <div>







* ⚠️ **WARN** <p>The dot of soft dotted characters used in orthographies <em>must</em> disappear in the following strings: į̀ į́ į̂ į̃ į̄ į̌ ị̀ ị́ ị̂ ị̃ ị̄</p>
<p>The dot of soft dotted characters <em>should</em> disappear in other cases, for example: i̒ ĭ̛ i̛̇ i̛̊ i̛̋ ǐ̛ i̛̒ ĭ̦ i̦̇ i̦̊ i̦̋ ǐ̦ i̦̒ ĭ̧ i̧̇ i̧̊ i̧̋ ǐ̧ i̧̒ j̒</p>
 [code: soft-dotted]



</div>
</details>

<details>
    <summary>⚠️ <b>WARN</b> Are there any misaligned on-curve points? <a href="https://fontbakery.readthedocs.io/en/stable/fontbakery/checks/universal.html#outline-alignment-miss">outline_alignment_miss</a></summary>
    <div>







* ⚠️ **WARN** <p>The following glyphs have on-curve points which have potentially incorrect y coordinates:</p>
<pre><code>* bracketleft (U+005B): X=1159.0,Y=1431.0 (should be at cap-height 1432?)

* bracketleft (U+005B): X=673.0,Y=1431.0 (should be at cap-height 1432?)

* bracketright (U+005D): X=847.0,Y=1431.0 (should be at cap-height 1432?)

* bracketright (U+005D): X=361.0,Y=1431.0 (should be at cap-height 1432?)

* i (U+0069): X=559.0,Y=1431.0 (should be at cap-height 1432?)

* i (U+0069): X=863.0,Y=1430.0 (should be at cap-height 1432?)

* j (U+006A): X=715.0,Y=1431.0 (should be at cap-height 1432?)

* j (U+006A): X=1019.0,Y=1430.0 (should be at cap-height 1432?)

* Atilde (U+00C3): X=508.5,Y=1933.5 (should be at ascender 1932?)

* Abreve (U+0102): X=638.0,Y=1933.0 (should be at ascender 1932?)

* uni1EB6 (U+1EB6): X=638.0,Y=1933.0 (should be at ascender 1932?)

* uni1EBC (U+1EBC): X=515.5,Y=1933.5 (should be at ascender 1932?)

* Gbreve (U+011E): X=685.0,Y=1933.0 (should be at ascender 1932?)

* uni0122 (U+0122): X=404.5,Y=-572.5 (should be at descender -572?)

* Itilde (U+0128): X=526.5,Y=1933.5 (should be at ascender 1932?)

* uni0136 (U+0136): X=435.5,Y=-572.5 (should be at descender -572?)

* uni013B (U+013B): X=433.5,Y=-572.5 (should be at descender -572?)

* Ntilde (U+00D1): X=487.5,Y=1933.5 (should be at ascender 1932?)

* uni0145 (U+0145): X=402.5,Y=-572.5 (should be at descender -572?)

* Otilde (U+00D5): X=516.5,Y=1933.5 (should be at ascender 1932?)

* uni0218 (U+0218): X=391.5,Y=-572.5 (should be at descender -572?)

* uni021A (U+021A): X=331.5,Y=-572.5 (should be at descender -572?)

* Utilde (U+0168): X=516.5,Y=1933.5 (should be at ascender 1932?)

* uni1EF8 (U+1EF8): X=489.5,Y=1933.5 (should be at ascender 1932?)

* atilde (U+00E3): X=802.0,Y=1432.5 (should be at cap-height 1432?)

* edotaccent (U+0117): X=612.0,Y=1433.0 (should be at cap-height 1432?)

* edotaccent (U+0117): X=922.0,Y=1433.0 (should be at cap-height 1432?)

* uni1EBD (U+1EBD): X=867.0,Y=1432.5 (should be at cap-height 1432?)

* iogonek (U+012F): X=559.0,Y=1431.0 (should be at cap-height 1432?)

* iogonek (U+012F): X=863.0,Y=1430.0 (should be at cap-height 1432?)

* ij (U+0133): X=336.0,Y=1431.0 (should be at cap-height 1432?)

* ij (U+0133): X=640.0,Y=1430.0 (should be at cap-height 1432?)

* ij (U+0133): X=999.0,Y=1431.0 (should be at cap-height 1432?)

* ij (U+0133): X=1303.0,Y=1430.0 (should be at cap-height 1432?)

* itilde (U+0129): X=815.0,Y=1432.5 (should be at cap-height 1432?)

* uni1ECB (U+1ECB): X=559.0,Y=1431.0 (should be at cap-height 1432?)

* uni1ECB (U+1ECB): X=863.0,Y=1430.0 (should be at cap-height 1432?)

* ntilde (U+00F1): X=857.0,Y=1432.5 (should be at cap-height 1432?)

* otilde (U+00F5): X=840.0,Y=1432.5 (should be at cap-height 1432?)

* uni0219 (U+0219): X=378.5,Y=-572.5 (should be at descender -572?)

* utilde (U+0169): X=812.0,Y=1432.5 (should be at cap-height 1432?)

* uni1EEF (U+1EEF): X=827.0,Y=1434.0 (should be at cap-height 1432?)

* uni1EF9 (U+1EF9): X=825.0,Y=1432.5 (should be at cap-height 1432?)

* zdotaccent (U+017C): X=601.0,Y=1433.0 (should be at cap-height 1432?)

* zdotaccent (U+017C): X=911.0,Y=1433.0 (should be at cap-height 1432?)

* tildecomb (U+0303): X=260.0,Y=1432.5 (should be at cap-height 1432?)

* uni0307 (U+0307): X=5.0,Y=1433.0 (should be at cap-height 1432?)

* uni0307 (U+0307): X=315.0,Y=1433.0 (should be at cap-height 1432?)

* uni0326 (U+0326): X=-258.5,Y=-572.5 (should be at descender -572?)
</code></pre>
 [code: found-misalignments]



</div>
</details>
</div>
</details>




### Summary

| 💥 ERROR | ☠ FATAL | 🔥 FAIL | ⚠️ WARN | ⏩ SKIP | ℹ️ INFO | ✅ PASS | 🔎 DEBUG | 
| ---|---|---|---|---|---|---|---|
| 0 | 0 | 2 | 12 | 173 | 13 | 250 | 0 | 
| 0% | 0% | 0% | 3% | 38% | 3% | 56% | 0% | 



**Note:** The following loglevels were omitted in this report:


* SKIP
* INFO
* PASS
* DEBUG
